(() => {
	const PLUGIN_ID = "codegallery.dart";
	const TITLE = "Dart";
	const EXT = ".dart";
	const BUILTIN = [];
	const SERVER = {
 "id": "dart",
 "label": "Dart (analysis server)",
 "languages": [
  "dart"
 ],
 "command": "dart",
 "args": [
  "language-server",
  "--protocol=lsp"
 ],
 "checkCommand": "which dart",
 "startupTimeout": 120000,
 "installer": [
  "shell",
  {
   "executable": "dart",
   "command": "apk add --no-cache --repository=https://dl-cdn.alpinelinux.org/alpine/edge/main --repository=https://dl-cdn.alpinelinux.org/alpine/edge/community --repository=https://dl-cdn.alpinelinux.org/alpine/edge/testing dart-sdk",
   "uninstallCommand": "apk del dart-sdk"
  }
 ]
};

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: true }));
			}
		} else if (SERVER) {
			const [kind, options] = SERVER.installer;
			const manifest = lsp.defineServer({
				...SERVER,
				installer: lsp.installers[kind](options),
				enabled: true,
			});
			lsp.upsert(manifest);
		}
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(
				`${TITLE} added. Open a ${EXT} file; the language server installs once (needs internet).`,
			);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: false }));
			}
		} else if (SERVER) {
			lsp.servers.unregister(SERVER.id);
		}
	});
})();
