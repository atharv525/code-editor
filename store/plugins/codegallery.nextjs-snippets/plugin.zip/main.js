(() => {
	const PLUGIN_ID = "codegallery.nextjs-snippets";
	const TITLE = "Next.js Snippets";
	const COMMAND = "nextjs-snippets";
	const SNIPPETS = [
 [
  "Page (app/page.tsx)",
  "export default function Page() {\n  return (\n    <main>\n      <h1>$0</h1>\n    </main>\n  );\n}\n"
 ],
 [
  "Layout (app/layout.tsx)",
  "export const metadata = {\n  title: \"My App\",\n  description: \"$0\",\n};\n\nexport default function RootLayout({ children }: { children: React.ReactNode }) {\n  return (\n    <html lang=\"en\">\n      <body>{children}</body>\n    </html>\n  );\n}\n"
 ],
 [
  "Client component with state",
  "\"use client\";\n\nimport { useState } from \"react\";\n\nexport default function Counter() {\n  const [count, setCount] = useState(0);\n  return <button onClick={() => setCount(count + 1)}>Clicked {count} times$0</button>;\n}\n"
 ],
 [
  "API route (app/api/route.ts)",
  "import { NextResponse } from \"next/server\";\n\nexport async function GET() {\n  return NextResponse.json({ ok: true$0 });\n}\n\nexport async function POST(request: Request) {\n  const body = await request.json();\n  return NextResponse.json({ received: body });\n}\n"
 ],
 [
  "Server component fetch",
  "export default async function Page() {\n  const res = await fetch(\"https://api.example.com/items\", { cache: \"no-store\" });\n  const items = await res.json();\n  return (\n    <ul>\n      {items.map((item: any) => (\n        <li key={item.id}>{item.name}</li>\n      ))}\n    </ul>\n  );\n}\n$0"
 ],
 [
  "Server action",
  "async function save(formData: FormData) {\n  \"use server\";\n  const name = formData.get(\"name\");\n  $0\n}\n"
 ],
 [
  "Dynamic route params",
  "export default async function Page({ params }: { params: Promise<{ id: string }> }) {\n  const { id } = await params;\n  return <h1>Item {id}$0</h1>;\n}\n"
 ],
 [
  "loading.tsx",
  "export default function Loading() {\n  return <p>Loading...$0</p>;\n}\n"
 ],
 [
  "Link and Image",
  "import Link from \"next/link\";\nimport Image from \"next/image\";\n\n<Link href=\"/about\">About</Link>\n<Image src=\"/logo.png\" alt=\"Logo\" width={120} height={40} />\n$0"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
