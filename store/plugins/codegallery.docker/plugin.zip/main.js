(() => {
	const PLUGIN_ID = "codegallery.docker";
	const TITLE = "Docker";
	const CFG = {
 "key": "docker",
 "snippets": [
  [
   "Dockerfile (Node)",
   "FROM node:22-alpine\nWORKDIR /app\nCOPY package*.json ./\nRUN npm ci --omit=dev\nCOPY . .\nEXPOSE 3000\nCMD [\"node\", \"$0index.js\"]\n"
  ],
  [
   "Dockerfile (Python)",
   "FROM python:3.12-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . .\nCMD [\"python\", \"$0app.py\"]\n"
  ],
  [
   "docker-compose.yml",
   "services:\n  app:\n    build: .\n    ports:\n      - \"3000:3000\"\n    environment:\n      - NODE_ENV=production\n  db:\n    image: postgres:16\n    environment:\n      POSTGRES_PASSWORD: secret\n    volumes:\n      - db:/var/lib/postgresql/data\nvolumes:\n  db:\n$0"
  ],
  [
   ".dockerignore",
   "node_modules\n.git\n*.log\n.env\n$0"
  ]
 ],
 "servers": [
  {
   "id": "dockerfile-language-server",
   "label": "Dockerfile",
   "languages": [
    "dockerfile"
   ],
   "command": "docker-langserver",
   "args": [
    "--stdio"
   ],
   "checkCommand": "which docker-langserver",
   "installer": [
    "npm",
    {
     "executable": "docker-langserver",
     "packages": [
      "dockerfile-language-server-nodejs"
     ]
    }
   ]
  }
 ],
 "terminal": [],
 "rest": false,
 "openapi": false,
 "features": [
  "docker"
 ],
 "builtins": []
};
	const added = [];

	function view() {
		const v = window.editorManager?.editor;
		if (!v) window.toast?.("Open a file first");
		return v;
	}

	function insert(v, body) {
		const sel = v.state.selection.main;
		const line = v.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		v.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		v.focus();
	}

	async function pickSnippet() {
		const v = view();
		if (!v) return;
		const select = acode.require("select");
		const value = await select(
			`${TITLE} snippets`,
			CFG.snippets.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const s = CFG.snippets[Number(value)];
		if (s) insert(v, s[1]);
	}

	function shellQuote(s) {
		const str = String(s);
		const q = (x) => `'${x.replace(/'/g, "'\\''")}'`;
		// keep $HOME expandable for paths inside the terminal home
		if (str === "$HOME" || str.startsWith("$HOME/")) return `"$HOME"${q(str.slice(5))}`;
		return q(str);
	}

	function toTerm(url) {
		if (!url) return null;
		const d = decodeURIComponent(String(url));
		const saf = d.match(
			/^content:\/\/com\.android\.externalstorage\.documents\/.*?primary:([^:]*)$/,
		);
		if (saf) return `/sdcard/${saf[1].replace(/^\/+/, "")}`.replace(/\/$/, "");
		const c = d.replace(/^file:\/\//, "");
		const st = c.match(/^\/storage\/emulated\/0(\/.*)?$/);
		if (st) return `/sdcard${st[1] || ""}`;
		if (c.startsWith("/sdcard")) return c;
		const pub = c.match(/\/files\/public(\/.*)?$/);
		if (pub) return `$HOME${pub[1] || ""}`;
		return null;
	}

	function toAppUrl(path) {
		if (path.startsWith("/sdcard")) return `file:///storage/emulated/0${path.slice(7)}`;
		const data = window.cordova?.file?.dataDirectory;
		if (data && (path === "$HOME" || path.startsWith("$HOME/"))) return `${data}public${path.slice(5)}`;
		return null;
	}

	function folders() {
		try {
			return acode.require("addedfolder") || [];
		} catch (_) {
			return [];
		}
	}

	function activePath() {
		return toTerm(window.editorManager?.activeFile?.uri);
	}

	function dirOf(path) {
		return path ? path.slice(0, path.lastIndexOf("/")) || "/" : null;
	}

	function projectDir() {
		const file = activePath();
		for (const f of folders()) {
			const p = toTerm(f.url);
			if (p && (!file || file.startsWith(`${p}/`))) return p;
		}
		return dirOf(file) || toTerm(folders()[0]?.url) || "";
	}

	function terminalDir() {
		return projectDir();
	}

	async function runInTerminal(t) {
		let cmd = t.cmd;
		if (t.ask) {
			const prompt = acode.require("prompt");
			const value = await prompt(t.ask, t.askDefault || "", "text");
			if (value === null || value === undefined) return;
			cmd = cmd.replace("{input}", shellQuote(value));
		}
		const term = await acode.require("terminal").create({ name: t.title });
		if (!term?.component) return;
		const start = Date.now();
		while (!term.component.isConnected && Date.now() - start < 15000) {
			await new Promise((r) => setTimeout(r, 300));
		}
		await new Promise((r) => setTimeout(r, 800));
		const dir = terminalDir();
		const cd = dir ? `cd ${shellQuote(dir)} 2>/dev/null; ` : "";
		term.component.write(`clear; ${cd}${cmd}\n`);
	}

	// ---------- REST client (.http / .rest files) ----------
	function currentRequest(v) {
		const doc = v.state.doc.toString();
		const pos = v.state.selection.main.head;
		const vars = {};
		for (const m of doc.matchAll(/^@([\w-]+)\s*=\s*(.*)$/gm)) vars[m[1]] = m[2].trim();
		const blocks = doc.split(/^###.*$/m);
		let offset = 0;
		let block = blocks[0];
		for (const b of blocks) {
			const end = offset + b.length;
			block = b;
			if (pos <= end) break;
			offset = end + (doc.slice(end).match(/^###.*/)?.[0].length || 0);
		}
		const fill = (s) => s.replace(/\{\{\s*([\w-]+)\s*\}\}/g, (_, k) => vars[k] ?? "");
		const lines = block.split("\n").map((l) => l.replace(/\r$/, ""));
		let i = 0;
		while (i < lines.length && (/^\s*$/.test(lines[i]) || /^\s*(#|\/\/)/.test(lines[i]) || /^@[\w-]+\s*=/.test(lines[i]))) i++;
		if (i >= lines.length) return null;
		const first = fill(lines[i]).trim().split(/\s+/);
		let method = "GET";
		let url = first[0];
		if (/^[A-Z]+$/.test(first[0])) {
			method = first[0];
			url = first[1];
		}
		const headers = {};
		i++;
		for (; i < lines.length && lines[i].trim() !== ""; i++) {
			const m = /^([\w-]+)\s*:\s*(.*)$/.exec(fill(lines[i]));
			if (m) headers[m[1]] = m[2];
		}
		const body = fill(lines.slice(i + 1).join("\n")).trim();
		return { method, url, headers, body };
	}

	function httpSend(req) {
		return new Promise((resolve, reject) => {
			const http = window.cordova?.plugin?.http;
			const started = Date.now();
			if (!http) {
				fetch(req.url, {
					method: req.method,
					headers: req.headers,
					body: ["GET", "HEAD"].includes(req.method) ? undefined : req.body || undefined,
				})
					.then(async (res) => {
						const headers = {};
						res.headers.forEach((v, k) => (headers[k] = v));
						resolve({ status: res.status, headers, data: await res.text(), ms: Date.now() - started });
					})
					.catch(reject);
				return;
			}
			const options = {
				method: req.method.toLowerCase(),
				headers: req.headers,
				serializer: "utf8",
				responseType: "text",
				timeout: 60,
			};
			if (!["GET", "HEAD"].includes(req.method)) options.data = req.body || "";
			const done = (res) =>
				resolve({
					status: res.status,
					headers: res.headers || {},
					data: res.data ?? res.error ?? "",
					ms: Date.now() - started,
				});
			http.sendRequest(req.url, options, done, (err) =>
				err && err.status > 0 ? done(err) : reject(new Error(err?.error || "Request failed")),
			);
		});
	}

	async function sendRequest() {
		const v = view();
		if (!v) return;
		const req = currentRequest(v);
		if (!req || !/^https?:\/\//.test(req.url || "")) {
			window.toast?.("Put the cursor on a request like: GET https://example.com");
			return;
		}
		const loader = acode.require("loader");
		loader.showTitleLoader?.();
		try {
			const res = await httpSend(req);
			let data = res.data;
			try {
				data = JSON.stringify(JSON.parse(data), null, 2);
			} catch (_) {}
			const head = Object.entries(res.headers)
				.map(([k, val]) => `${k}: ${val}`)
				.join("\n");
			const text = `HTTP ${res.status}  (${res.ms} ms)\n${req.method} ${req.url}\n\n${head}\n\n${data}`;
			const EditorFile = acode.require("EditorFile");
			new EditorFile(`Response ${res.status}.http`, { text, isUnsaved: false });
		} catch (e) {
			window.toast?.(`Request failed: ${e.message || e}`);
		} finally {
			loader.removeTitleLoader?.();
		}
	}

	// ---------- OpenAPI preview ----------
	function previewOpenApi() {
		const v = view();
		if (!v) return;
		const spec = v.state.doc.toString();
		if (!/openapi|swagger/i.test(spec)) {
			window.toast?.("This file does not look like an OpenAPI / Swagger spec");
			return;
		}
		const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"><style>body{margin:0;background:#fff}</style></head><body><div id="ui">Loading preview (needs internet)...</div>
<script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script><script src="https://unpkg.com/js-yaml@4/dist/js-yaml.min.js"></script>
<script>try{const t=${JSON.stringify(spec).replace(/</g, "\\u003c")};let s;try{s=JSON.parse(t)}catch(_){s=jsyaml.load(t)}SwaggerUIBundle({spec:s,dom_id:"#ui"})}catch(e){document.body.textContent="Spec error: "+e.message}</script></body></html>`;
		const Page = acode.require("page");
		const page = Page("API Preview");
		const frame = document.createElement("iframe");
		frame.style.cssText = "width:100%;height:100%;border:0;background:#fff";
		frame.srcdoc = html;
		page.body = frame;
		window.app.append(page);
		const stack = acode.require("actionStack");
		stack?.push({ id: "openapi-preview", action: page.hide });
		page.onhide = () => stack?.remove("openapi-preview");
	}

	function addCommand(name, description, exec) {
		acode.addCommand({ name, description, requiresView: false, exec() { exec(); return true; } });
		added.push(name);
	}

	// ================= shared helpers =================
	function sh(cmd) {
		const ex = window.Executor;
		if (!ex) return Promise.reject(new Error("Terminal is not installed. Open the Terminal once first."));
		return ex.execute(`sh -lc ${shellQuote(cmd)}`, true).then((out) => String(out ?? ""));
	}

	function errText(e) {
		return String(e?.message || e || "Failed").trim().slice(0, 400);
	}

	async function hasAllFilesAccess(path) {
		if (!path || !path.startsWith("/sdcard")) return true;
		if (!(window.ANDROID_SDK_INT >= 30) || !window.system?.hasGrantedStorageManager) return true;
		const ok = await new Promise((resolve) =>
			system.hasGrantedStorageManager((v) => resolve(String(v) === "true"), () => resolve(true)),
		);
		if (ok) return true;
		const confirm = acode.require("confirm");
		if (await confirm("All files access", "The terminal needs \"All files access\" to work with files in phone storage. Turn it on for Code Editor on the next screen, then try again.")) {
			system.requestStorageManager(console.log, console.error);
		}
		return false;
	}

	async function openTerminal(title, cmd, dir) {
		if (dir && !(await hasAllFilesAccess(dir))) return null;
		const api = acode.require("terminal");
		const term = await api.create({ name: title });
		if (!term?.component) return null;
		const start = Date.now();
		while (!term.component.isConnected && Date.now() - start < 15000) {
			await new Promise((r) => setTimeout(r, 300));
		}
		await new Promise((r) => setTimeout(r, 800));
		const cd = dir ? `cd ${shellQuote(dir)} 2>/dev/null; ` : "";
		term.component.write(`clear; ${cd}${cmd}\n`);
		return term;
	}

	function esc(s) {
		return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
	}

	const STYLE = `
.cg-wrap{padding:10px;overflow:auto;height:100%;box-sizing:border-box;font-size:14px;color:var(--primary-text-color)}
.cg-row{display:flex;gap:6px;margin:6px 0;flex-wrap:wrap;align-items:center}
.cg-wrap input,.cg-wrap select,.cg-wrap textarea{background:var(--secondary-color);color:var(--secondary-text-color);border:1px solid var(--border-color);border-radius:6px;padding:8px;font:inherit;box-sizing:border-box}
.cg-wrap textarea{width:100%;min-height:90px;font-family:monospace;font-size:13px}
.cg-wrap button{background:var(--button-background-color);color:var(--button-text-color);border:0;border-radius:6px;padding:8px 14px;font:inherit}
.cg-wrap button.sec{background:var(--secondary-color);color:var(--secondary-text-color);border:1px solid var(--border-color)}
.cg-mono{font-family:monospace;font-size:12.5px;white-space:pre;overflow:auto}
.cg-table{border-collapse:collapse;font-size:12.5px;font-family:monospace}
.cg-table th,.cg-table td{border:1px solid var(--border-color);padding:4px 8px;text-align:left;white-space:nowrap;max-width:320px;overflow:hidden;text-overflow:ellipsis}
.cg-table th{background:var(--secondary-color);position:sticky;top:0}
.cg-item{padding:8px;border-bottom:1px solid var(--border-color)}
.cg-muted{opacity:.65;font-size:12px}
.cg-chip{display:inline-block;padding:1px 6px;border-radius:9px;background:var(--active-color);color:#fff;font-size:11px;margin-right:4px}
.cg-graph{color:var(--active-color)}
.cg-ok{color:#22c55e}.cg-bad{color:#ef4444}`;

	function showPage(title, html, id) {
		const Page = acode.require("page");
		const page = Page(title);
		const wrap = document.createElement("div");
		wrap.className = "cg-wrap";
		wrap.innerHTML = `<style>${STYLE}</style>${html}`;
		page.body = wrap;
		window.app.append(page);
		const stack = acode.require("actionStack");
		const sid = `${PLUGIN_ID}-${id || "page"}-${Date.now()}`;
		stack?.push({ id: sid, action: page.hide });
		page.onhide = () => stack?.remove(sid);
		return { page, wrap, $: (sel) => wrap.querySelector(sel) };
	}

	function openText(name, text) {
		const EditorFile = acode.require("EditorFile");
		return new EditorFile(name, { text, isUnsaved: false });
	}

	async function openAt(path, line) {
		const url = toAppUrl(path);
		if (!url) {
			window.toast?.(`Can't open ${path}`);
			return;
		}
		await acode.require("openFile")(url, { cursorPos: { row: Math.max(1, Number(line) || 1), column: 0 } });
	}

	async function pick(title, items) {
		const select = acode.require("select");
		return select(title, items);
	}

	async function ask(title, def = "", type = "text") {
		const prompt = acode.require("prompt");
		const v = await prompt(title, def, type);
		return v === null || v === undefined ? null : String(v);
	}

	function wordAtCursor(v, re = /[\w-]/) {
		const pos = v.state.selection.main.head;
		const line = v.state.doc.lineAt(pos);
		let a = pos - line.from;
		let b = a;
		while (a > 0 && re.test(line.text[a - 1])) a--;
		while (b < line.text.length && re.test(line.text[b])) b++;
		return line.text.slice(a, b);
	}

	function parseDelimited(text, sep) {
		const rows = [];
		let row = [];
		let cell = "";
		let q = false;
		for (let i = 0; i < text.length; i++) {
			const c = text[i];
			if (sep === "," && q) {
				if (c === '"' && text[i + 1] === '"') {
					cell += '"';
					i++;
				} else if (c === '"') q = false;
				else cell += c;
				continue;
			}
			if (sep === "," && c === '"' && cell === "") q = true;
			else if (c === sep) {
				row.push(cell);
				cell = "";
			} else if (c === "\n") {
				row.push(cell);
				rows.push(row);
				row = [];
				cell = "";
			} else if (c !== "\r") cell += c;
		}
		if (cell !== "" || row.length) {
			row.push(cell);
			rows.push(row);
		}
		return rows;
	}

	function tableHtml(rows) {
		if (!rows.length) return '<div class="cg-muted">No rows.</div>';
		const [head, ...body] = rows;
		return `<div class="cg-muted">${body.length} row(s)</div><div style="overflow:auto"><table class="cg-table"><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>${body
			.map((r) => `<tr>${r.map((c) => `<td title="${esc(c)}">${esc(c)}</td>`).join("")}</tr>`)
			.join("")}</table></div>`;
	}

	const store = {
		get(k, d) {
			try {
				return JSON.parse(localStorage.getItem(`${PLUGIN_ID}.${k}`)) ?? d;
			} catch (_) {
				return d;
			}
		},
		set(k, v) {
			localStorage.setItem(`${PLUGIN_ID}.${k}`, JSON.stringify(v));
		},
	};

	function needFile(exts) {
		const p = activePath();
		if (!p) {
			window.toast?.("Open a file from phone storage first");
			return null;
		}
		if (exts && !exts.test(p)) {
			window.toast?.("This command needs a different file type");
			return null;
		}
		return p;
	}

	// ================= Live Server =================
	let liveTerm = null;
	async function waitFor(url, ms) {
		const end = Date.now() + ms;
		while (Date.now() < end) {
			try {
				const r = await fetch(url, { cache: "no-store" });
				if (r.ok || r.status < 500) return true;
			} catch (_) {}
			await new Promise((r) => setTimeout(r, 1500));
		}
		return false;
	}
	async function liveStart() {
		const dir = projectDir();
		if (!dir) {
			window.toast?.("Open a folder or an HTML file from phone storage first");
			return;
		}
		const port = 5500;
		liveTerm = await openTerminal(
			"Live Server",
			`(command -v node >/dev/null || apk add --no-cache nodejs npm) && echo "Live Server: http://127.0.0.1:${port}  (auto reload on save, Ctrl+C to stop)" && npx --yes live-server@1.2.2 --port=${port} --host=127.0.0.1 --no-browser`,
			dir,
		);
		if (!liveTerm) return;
		const file = activePath();
		const rel = file && file.startsWith(`${dir}/`) && /\.html?$/i.test(file) ? file.slice(dir.length) : "/";
		window.toast?.("Starting Live Server (first time downloads it)...");
		if (await waitFor(`http://127.0.0.1:${port}/`, 180000)) acode.require("browser").open(`http://127.0.0.1:${port}${encodeURI(rel)}`);
		else window.toast?.("Live Server did not start. Check the Live Server terminal.");
	}
	function liveStop() {
		if (liveTerm?.id) acode.require("terminal").close(liveTerm.id);
		liveTerm = null;
		window.toast?.("Live Server stopped");
	}

	// ================= JS Debugger =================
	async function nodeRun(debug) {
		const p = needFile(/\.(m?js|cjs)$/i);
		if (!p) return;
		const name = p.slice(p.lastIndexOf("/") + 1);
		const help = debug
			? 'echo "Debugger: c=continue  n=next  s=step in  o=step out  repl=inspect vars (Ctrl+C to leave repl)  .exit=quit. Add debugger; in code for breakpoints, or sb(LINE)."; '
			: "";
		await openTerminal(
			debug ? "JS Debugger" : "Node",
			`(command -v node >/dev/null || apk add --no-cache nodejs npm) && ${help}node ${debug ? "inspect " : ""}${shellQuote(name)}`,
			dirOf(p),
		);
	}

	// ================= Auto Rename Tag =================
	function renameTagExtension() {
		const { EditorView } = acode.require("@codemirror/view");
		const NAME = /[\w:.-]/;
		const HTMLISH = /\.(html?|xml|svg|vue|svelte|php|jsx|tsx|astro|xhtml)$/i;
		let pending = null; // tag name emptied: remember its partner
		return EditorView.updateListener.of((u) => {
			if (!u.docChanged || u.transactions.some((t) => t.isUserEvent("rename-tag"))) return;
			if (!u.transactions.some((t) => t.isUserEvent("input") || t.isUserEvent("delete"))) return;
			const uri = window.editorManager?.activeFile?.filename || "";
			if (!HTMLISH.test(uri)) return;
			const head = u.state.selection.main.head;
			const line = u.state.doc.lineAt(head);
			let a = head - line.from;
			while (a > 0 && NAME.test(line.text[a - 1])) a--;
			let b = head - line.from;
			while (b < line.text.length && NAME.test(line.text[b])) b++;
			const before = line.text.slice(0, a);
			const closing = before.endsWith("</");
			if (!closing && !before.endsWith("<")) return;
			const startNew = line.from + a;
			const newName = line.text.slice(a, b);
			const oldStart = u.changes.invertedDesc.mapPos(startNew, -1);
			const oldText = u.startState.doc.toString();
			let e = oldStart;
			while (e < oldText.length && NAME.test(oldText[e])) e++;
			let oldName = oldText.slice(oldStart, e);
			if (!oldName && pending && pending.start === oldStart && pending.closing === closing) {
				const target = pending.target;
				const name = pending.name;
				pending = null;
				if (!newName || oldText.slice(target, target + name.length) !== name) return;
				const from = u.changes.mapPos(target, 1);
				const to = u.changes.mapPos(target + name.length, -1);
				const view = u.view;
				setTimeout(() => {
					if (view.state.doc.sliceString(from, to) !== name) return;
					view.dispatch({ changes: { from, to, insert: newName }, userEvent: "rename-tag" });
				}, 0);
				return;
			}
			if (!oldName || oldName === newName) return;
			const reEsc = oldName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
			const tagRe = new RegExp(`<(/?)${reEsc}(?=[\\s>/])`, "g");
			let target = -1;
			if (!closing) {
				const tagEnd = oldText.indexOf(">", e);
				if (tagEnd < 0 || oldText[tagEnd - 1] === "/") return;
				tagRe.lastIndex = tagEnd;
				let depth = 0;
				let m;
				while ((m = tagRe.exec(oldText))) {
					if (!m[1]) {
						const end = oldText.indexOf(">", m.index);
						if (end > 0 && oldText[end - 1] !== "/") depth++;
					} else if (depth === 0) {
						target = m.index + 2;
						break;
					} else depth--;
				}
			} else {
				const all = [];
				let m;
				tagRe.lastIndex = 0;
				while ((m = tagRe.exec(oldText)) && m.index < oldStart - 2) all.push(m);
				let depth = 0;
				for (let i = all.length - 1; i >= 0; i--) {
					const t = all[i];
					if (t[1]) depth++;
					else {
						const end = oldText.indexOf(">", t.index);
						if (end > 0 && oldText[end - 1] === "/") continue;
						if (depth === 0) {
							target = t.index + 1;
							break;
						}
						depth--;
					}
				}
			}
			if (target < 0) return;
			if (!newName) {
				pending = { start: startNew, closing, target: u.changes.mapPos(target, 1), name: oldName };
				return;
			}
			pending = null;
			const from = u.changes.mapPos(target, 1);
			const to = u.changes.mapPos(target + oldName.length, -1);
			if (from >= startNew - 1 && from <= startNew + newName.length) return;
			const view = u.view;
			setTimeout(() => {
				if (view.state.doc.sliceString(from, to) !== oldName) return;
				view.dispatch({ changes: { from, to, insert: newName }, userEvent: "rename-tag" });
			}, 0);
		});
	}

	// ================= CSS Peek + HTML CSS class completion =================
	async function cssPeek() {
		const v = view();
		if (!v) return;
		const word = wordAtCursor(v);
		if (!word) {
			window.toast?.("Put the cursor on a class or id name");
			return;
		}
		const dir = projectDir();
		if (!dir || !(await hasAllFilesAccess(dir))) return;
		const re = `[.#]${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^A-Za-z0-9_-]|$)`;
		let out = "";
		try {
			out = await sh(`grep -rnE --include='*.css' --include='*.scss' --include='*.less' --include='*.sass' --include='*.html' --exclude-dir=node_modules --exclude-dir=.git -- ${shellQuote(re)} ${shellQuote(dir)} | head -60; true`);
		} catch (e) {
			window.toast?.(errText(e));
			return;
		}
		const hits = out.split("\n").filter(Boolean).map((l) => {
			const m = l.match(/^(.*?):(\d+):(.*)$/);
			return m && { file: m[1], line: m[2], text: m[3].trim() };
		}).filter(Boolean).filter((h) => /\.(css|scss|less|sass)$/i.test(h.file) || /[{]/.test(h.text));
		if (!hits.length) {
			window.toast?.(`No CSS rule found for "${word}"`);
			return;
		}
		const idx = hits.length === 1 ? "0" : await pick(`CSS for "${word}"`, hits.map((h, i) => [String(i), `${h.file.slice(h.file.lastIndexOf("/") + 1)}:${h.line}  ${h.text.slice(0, 80)}`, "code"]));
		if (idx === undefined || idx === null) return;
		const h = hits[Number(idx)];
		openAt(h.file, h.line);
	}

	let classCache = { dir: "", at: 0, list: [] };
	async function projectClasses() {
		const dir = projectDir();
		if (!dir) return [];
		if (classCache.dir === dir && Date.now() - classCache.at < 30000) return classCache.list;
		let out = "";
		try {
			out = await sh(`grep -rhoE --include='*.css' --include='*.scss' --include='*.less' --exclude-dir=node_modules --exclude-dir=.git '\\.[A-Za-z_][A-Za-z0-9_-]*' ${shellQuote(dir)} 2>/dev/null | sort -u | head -3000; true`);
		} catch (_) {}
		const list = out.split("\n").map((s) => s.slice(1)).filter((s) => s && !/^\d/.test(s));
		classCache = { dir, at: Date.now(), list };
		return list;
	}
	function classCompletionExtension() {
		const { EditorState } = acode.require("@codemirror/state");
		const source = async (ctx) => {
			const line = ctx.state.doc.lineAt(ctx.pos);
			const before = line.text.slice(0, ctx.pos - line.from);
			const m = before.match(/\bclass(Name)?\s*=\s*["']([^"']*)$/);
			if (!m) return null;
			const word = m[2].match(/[\w-]*$/)[0];
			const inDoc = [...ctx.state.doc.toString().matchAll(/\.([A-Za-z_][\w-]*)\s*[{,:\s]/g)].map((x) => x[1]);
			const names = [...new Set([...inDoc, ...(await projectClasses())])];
			if (!names.length) return null;
			return {
				from: ctx.pos - word.length,
				options: names.map((n) => ({ label: n, type: "class", detail: "CSS class" })),
				validFor: /^[\w-]*$/,
			};
		};
		return EditorState.languageData.of(() => [{ autocomplete: source }]);
	}

	// ================= Prettier format on save =================
	function prettierToggle() {
		const settings = acode.require("settings");
		const on = !settings.value.formatOnSave;
		settings.update({ formatOnSave: on }, false);
		window.toast?.(`Format on save: ${on ? "ON" : "OFF"}`);
	}
	function prettierFormat() {
		acode.exec("format");
	}

	// ================= Git =================
	const GIT_SETUP = "command -v git >/dev/null || apk add --no-cache git >/dev/null; git config --global --get-all safe.directory | grep -qx '\\*' || git config --global --add safe.directory '*'";
	async function git(dir, args) {
		return sh(`${GIT_SETUP}; cd ${shellQuote(dir)} && git ${args}`);
	}
	async function gitRoot() {
		const p = activePath();
		const dir = (p && dirOf(p)) || projectDir();
		if (!dir) {
			window.toast?.("Open a file or folder from phone storage first");
			return null;
		}
		if (!(await hasAllFilesAccess(dir))) return null;
		try {
			return (await git(dir, "rev-parse --show-toplevel")).trim();
		} catch (_) {
			window.toast?.("This folder is not a Git repository (use Git: Init or Clone)");
			return null;
		}
	}
	function ago(sec) {
		const s = Math.max(0, Date.now() / 1000 - Number(sec));
		const u = [[31536000, "year"], [2592000, "month"], [604800, "week"], [86400, "day"], [3600, "hour"], [60, "minute"]];
		for (const [n, w] of u) if (s >= n) { const k = Math.floor(s / n); return `${k} ${w}${k > 1 ? "s" : ""} ago`; }
		return "just now";
	}
	const blameCache = new Map();
	async function loadBlame(path) {
		const root = dirOf(path);
		const out = await git(root, `blame --line-porcelain -- ${shellQuote(path.slice(path.lastIndexOf("/") + 1))}`);
		const lines = [];
		let cur = {};
		for (const l of out.split("\n")) {
			if (/^[0-9a-f]{40} /.test(l)) {
				const [hash, , final] = l.split(" ");
				cur = { hash, line: Number(final) };
			} else if (l.startsWith("author ")) cur.author = l.slice(7);
			else if (l.startsWith("author-time ")) cur.time = Number(l.slice(12));
			else if (l.startsWith("summary ")) cur.summary = l.slice(8);
			else if (l.startsWith("\t")) lines[cur.line] = cur;
		}
		return lines;
	}
	function blameText(b) {
		if (!b) return "";
		if (/^0+$/.test(b.hash)) return "You • Not committed yet";
		return `${b.author}, ${ago(b.time)} • ${b.summary}`;
	}
	function inlineBlameExtension() {
		const { ViewPlugin, Decoration, WidgetType } = acode.require("@codemirror/view");
		class W extends WidgetType {
			constructor(t) { super(); this.t = t; }
			eq(o) { return o.t === this.t; }
			toDOM() {
				const s = document.createElement("span");
				s.textContent = `    ${this.t}`;
				s.style.cssText = "opacity:.45;font-style:italic;pointer-events:none;white-space:pre";
				return s;
			}
		}
		return ViewPlugin.fromClass(class {
			constructor(view) { this.view = view; this.decorations = Decoration.none; this.timer = 0; this.schedule(); }
			update(u) { if (u.selectionSet || u.docChanged || u.viewportChanged) { this.decorations = Decoration.none; this.schedule(); } }
			schedule() {
				clearTimeout(this.timer);
				this.timer = setTimeout(() => this.run(), 600);
			}
			async run() {
				if (store.get("inlineBlame", true) === false) return;
				const p = activePath();
				if (!p) return;
				const file = window.editorManager?.activeFile;
				if (file?.isUnsaved) return;
				let entry = blameCache.get(p);
				if (!entry || Date.now() - entry.at > 20000) {
					try { entry = { at: Date.now(), lines: await loadBlame(p) }; } catch (_) { entry = { at: Date.now(), lines: [] }; }
					blameCache.set(p, entry);
				}
				const v = this.view;
				const line = v.state.doc.lineAt(v.state.selection.main.head);
				const text = blameText(entry.lines[line.number]);
				if (!text) return;
				this.decorations = Decoration.set([Decoration.widget({ widget: new W(text), side: 1 }).range(line.to)]);
				v.dispatch({ effects: [] });
			}
			destroy() { clearTimeout(this.timer); }
		}, { decorations: (p) => p.decorations });
	}
	async function blameLine() {
		const p = needFile();
		const v = view();
		if (!p || !v || !(await gitRoot())) return;
		try {
			const lines = await loadBlame(p);
			const n = v.state.doc.lineAt(v.state.selection.main.head).number;
			const b = lines[n];
			if (!b) return window.toast?.("No blame for this line");
			const show = await git(dirOf(p), `show --stat --format='commit %H%nAuthor: %an <%ae>%nDate:   %ad%n%n%B' ${b.hash}`);
			openText(`blame ${b.hash.slice(0, 7)}.diff`, show);
		} catch (e) {
			window.toast?.(errText(e));
		}
	}
	async function fileHistory() {
		const p = needFile();
		if (!p || !(await gitRoot())) return;
		try {
			const out = await git(dirOf(p), `log --follow -n 100 --format='%h%x09%ar%x09%an%x09%s' -- ${shellQuote(p.slice(p.lastIndexOf("/") + 1))}`);
			const rows = out.split("\n").filter(Boolean).map((l) => l.split("\t"));
			if (!rows.length) return window.toast?.("No commits for this file yet");
			const h = await pick("File history", rows.map((r) => [r[0], `${r[0]}  ${r[3]}  (${r[2]}, ${r[1]})`, "history"]));
			if (!h) return;
			const diff = await git(dirOf(p), `show ${h} -- ${shellQuote(p.slice(p.lastIndexOf("/") + 1))}`);
			openText(`${h}.diff`, diff);
		} catch (e) {
			window.toast?.(errText(e));
		}
	}
	async function gitStatusPage() {
		const root = await gitRoot();
		if (!root) return;
		let status = "";
		let branch = "";
		try {
			status = await git(root, "status --porcelain=v1");
			branch = (await git(root, "branch --show-current")).trim();
		} catch (e) {
			return window.toast?.(errText(e));
		}
		const files = status.split("\n").filter(Boolean).map((l) => ({ code: l.slice(0, 2), file: l.slice(3) }));
		const pg = showPage("Source Control", `
<div class="cg-muted">${esc(root)} • branch <b>${esc(branch || "(none)")}</b></div>
<div class="cg-row"><input id="msg" placeholder="Commit message" style="flex:1"><button id="commit">Commit all</button></div>
<div class="cg-row"><button class="sec" id="pull">Pull</button><button class="sec" id="push">Push</button><button class="sec" id="refresh">Refresh</button></div>
<div>${files.length ? files.map((f) => `<div class="cg-item"><span class="cg-chip">${esc(f.code.trim() || "?")}</span><a data-f="${esc(f.file)}" style="color:inherit">${esc(f.file)}</a></div>`).join("") : '<div class="cg-muted">No changes. Working tree clean.</div>'}</div>`, "scm");
		pg.wrap.querySelectorAll("a[data-f]").forEach((a) => (a.onclick = async () => {
			try {
				const d = await git(root, `diff HEAD -- ${shellQuote(a.dataset.f)}`);
				openText(`${a.dataset.f.split("/").pop()}.diff`, d || "(new file, not tracked yet)");
			} catch (e) { window.toast?.(errText(e)); }
		}));
		pg.$("#commit").onclick = async () => {
			const msg = pg.$("#msg").value.trim();
			if (!msg) return window.toast?.("Write a commit message");
			try {
				const name = (await git(root, "config user.name").catch(() => "")).trim();
				if (!name) {
					const n = await ask("Your name for commits", "Code Gallery");
					const em = await ask("Your email for commits", "");
					if (!n || !em) return;
					await git(root, `config --global user.name ${shellQuote(n)} && git config --global user.email ${shellQuote(em)}`);
				}
				await git(root, `add -A && git commit -m ${shellQuote(msg)}`);
				window.toast?.("Committed");
				pg.page.hide();
				gitStatusPage();
			} catch (e) { window.toast?.(errText(e)); }
		};
		pg.$("#pull").onclick = () => openTerminal("Git", `${GIT_SETUP}; git pull`, root);
		pg.$("#push").onclick = () => openTerminal("Git", `${GIT_SETUP}; git push -u origin HEAD`, root);
		pg.$("#refresh").onclick = () => { pg.page.hide(); gitStatusPage(); };
	}
	async function gitInit() {
		const dir = projectDir();
		if (!dir || !(await hasAllFilesAccess(dir))) return;
		try {
			await git(dir, "init -b main");
			window.toast?.("Git repository created");
		} catch (e) { window.toast?.(errText(e)); }
	}
	function toggleInlineBlame() {
		const on = store.get("inlineBlame", true) === false;
		store.set("inlineBlame", on);
		window.toast?.(`Inline blame: ${on ? "ON" : "OFF"}`);
	}

	// ================= Git Graph =================
	const LANE_COLORS = ["#22d3ee", "#a78bfa", "#f472b6", "#facc15", "#34d399", "#fb923c"];
	async function gitGraphPage() {
		const root = await gitRoot();
		if (!root) return;
		let out = "";
		try {
			out = await git(root, "log --all --graph --date-order -n 400 --format='%x01%h%x02%d%x02%s%x02%an%x02%ar'");
		} catch (e) {
			return window.toast?.(errText(e));
		}
		const html = out.split("\n").map((l) => {
			const i = l.indexOf("\x01");
			const graph = i < 0 ? l : l.slice(0, i);
			const g = esc(graph).replace(/[*|/\\_]/g, (c, idx) => `<span style="color:${LANE_COLORS[Math.floor(idx / 2) % LANE_COLORS.length]}">${c === "*" ? "●" : c}</span>`);
			if (i < 0) return `<div class="cg-mono">${g}</div>`;
			const [h, refs, subj, an, ar] = l.slice(i + 1).split("\x02");
			const chips = (refs || "").replace(/[()]/g, "").split(",").map((r) => r.trim()).filter(Boolean).map((r) => `<span class="cg-chip">${esc(r.replace("HEAD -> ", "HEAD→"))}</span>`).join("");
			return `<div class="cg-mono" data-h="${esc(h)}">${g} <b>${esc(h)}</b> ${chips}${esc(subj)} <span class="cg-muted">${esc(an)}, ${esc(ar)}</span></div>`;
		}).join("");
		const pg = showPage("Git Graph", `<div class="cg-row"><button class="sec" id="br">Branches</button><button class="sec" id="fetch">Fetch</button><span class="cg-muted">Tap a commit to see changes</span></div><div style="overflow:auto">${html}</div>`, "graph");
		pg.wrap.querySelectorAll("[data-h]").forEach((d) => (d.onclick = async () => {
			try { openText(`${d.dataset.h}.diff`, await git(root, `show --stat -p ${d.dataset.h}`)); } catch (e) { window.toast?.(errText(e)); }
		}));
		pg.$("#br").onclick = () => gitBranches(root);
		pg.$("#fetch").onclick = () => openTerminal("Git", `${GIT_SETUP}; git fetch --all --prune`, root);
	}
	async function gitBranches(rootArg) {
		const root = rootArg || (await gitRoot());
		if (!root) return;
		try {
			const out = await git(root, "branch -a --format='%(refname:short)'");
			const list = out.split("\n").filter(Boolean);
			const b = await pick("Checkout branch", [["__new", "+ New branch", "add"], ...list.map((x) => [x, x, "call_split"])]);
			if (!b) return;
			if (b === "__new") {
				const n = await ask("New branch name", "feature/");
				if (!n) return;
				await git(root, `checkout -b ${shellQuote(n)}`);
			} else await git(root, `checkout ${shellQuote(b.replace(/^origin\//, ""))}`);
			window.toast?.("Switched branch. Reopen files to see changes.");
		} catch (e) { window.toast?.(errText(e)); }
	}

	// ================= GitHub (gh CLI) =================
	const GH = "command -v gh >/dev/null || apk add --no-cache github-cli git >/dev/null";
	async function ghLogin() {
		await openTerminal("GitHub", `${GH}; echo "Choose GitHub.com > HTTPS > Login with a web browser. Open the link shown and enter the code."; gh auth login -p https -w && gh auth setup-git && echo "Logged in."`, "");
	}
	async function gh(dir, args) {
		return sh(`${GH}; ${GIT_SETUP}; ${dir ? `cd ${shellQuote(dir)} && ` : ""}gh ${args}`);
	}
	async function ghReady() {
		try {
			await gh("", "auth status");
			return true;
		} catch (_) {
			if (await acode.require("confirm")("GitHub", "You are not logged in to GitHub yet. Log in now?")) ghLogin();
			return false;
		}
	}
	async function prList() {
		const root = await gitRoot();
		if (!root || !(await ghReady())) return;
		try {
			const prs = JSON.parse(await gh(root, "pr list --state open --limit 50 --json number,title,author,headRefName,isDraft"));
			if (!prs.length) return window.toast?.("No open pull requests");
			const n = await pick("Pull requests", prs.map((p) => [String(p.number), `#${p.number} ${p.title} (${p.author?.login || ""} • ${p.headRefName})${p.isDraft ? " [draft]" : ""}`, "merge_type"]));
			if (!n) return;
			const act = await pick(`PR #${n}`, [["view", "View details", "visibility"], ["diff", "View changes (diff)", "difference"], ["checkout", "Checkout branch", "call_split"], ["comment", "Add comment", "comment"], ["approve", "Approve", "check"], ["merge", "Merge (squash)", "merge_type"], ["web", "Open on GitHub", "public"]]);
			if (act === "view") openText(`PR-${n}.md`, await gh(root, `pr view ${n} --comments`));
			else if (act === "diff") openText(`PR-${n}.diff`, await gh(root, `pr diff ${n}`));
			else if (act === "checkout") { await gh(root, `pr checkout ${n}`); window.toast?.(`Checked out PR #${n}`); }
			else if (act === "comment") { const c = await ask("Comment", "", "textarea"); if (c) { await gh(root, `pr comment ${n} --body ${shellQuote(c)}`); window.toast?.("Comment added"); } }
			else if (act === "approve") { await gh(root, `pr review ${n} --approve`); window.toast?.("Approved"); }
			else if (act === "merge") { if (await acode.require("confirm")("Merge", `Squash and merge PR #${n}?`)) { await gh(root, `pr merge ${n} --squash`); window.toast?.("Merged"); } }
			else if (act === "web") { const url = (await gh(root, `pr view ${n} --json url -q .url`)).trim(); window.system?.openInBrowser?.(url); }
		} catch (e) { window.toast?.(errText(e)); }
	}
	async function prCreate() {
		const root = await gitRoot();
		if (!root || !(await ghReady())) return;
		const title = await ask("Pull request title", "");
		if (!title) return;
		const body = (await ask("Description (optional)", "", "textarea")) || "";
		try {
			const base = (await git(root, "remote show origin | sed -n 's/.*HEAD branch: //p'")).trim() || "main";
			await openTerminal("GitHub", `${GH}; git push -u origin HEAD && gh pr create --base ${shellQuote(base)} --title ${shellQuote(title)} --body ${shellQuote(body)}`, root);
		} catch (e) { window.toast?.(errText(e)); }
	}
	async function repoClone() {
		let list = [];
		try {
			await gh("", "auth status");
			list = JSON.parse(await gh("", "repo list --limit 100 --json nameWithOwner,description,isPrivate"));
		} catch (_) {}
		let repo = null;
		if (list.length) {
			repo = await pick("Your repositories", [["__url", "Enter URL or owner/name...", "link"], ...list.map((r) => [r.nameWithOwner, `${r.nameWithOwner}${r.isPrivate ? " 🔒" : ""}${r.description ? ` — ${r.description.slice(0, 60)}` : ""}`, "book"])]);
			if (!repo) return;
		}
		if (!repo || repo === "__url") {
			repo = await ask("Repository (URL or owner/name)", "https://github.com/");
			if (!repo) return;
		}
		const name = repo.replace(/\.git$/, "").split("/").pop();
		const base = "/sdcard/Projects";
		if (!(await hasAllFilesAccess(base))) return;
		const url = /^(https?:|git@)/.test(repo) ? repo : `https://github.com/${repo}.git`;
		const loader = acode.require("loader");
		loader.showTitleLoader?.();
		try {
			await sh(`${GIT_SETUP}; mkdir -p ${base} && cd ${base} && (command -v gh >/dev/null && gh auth status >/dev/null 2>&1 && gh repo clone ${shellQuote(repo)} ${shellQuote(name)} || git clone ${shellQuote(url)} ${shellQuote(name)})`);
			acode.require("openfolder")(toAppUrl(`${base}/${name}`), { name });
			window.toast?.(`Cloned to Projects/${name}`);
		} catch (e) {
			window.toast?.(`Clone failed: ${errText(e)}`);
		} finally {
			loader.removeTitleLoader?.();
		}
	}
	async function repoWeb() {
		const root = await gitRoot();
		if (!root) return;
		try {
			const url = (await git(root, "remote get-url origin")).trim().replace(/^git@github\.com:/, "https://github.com/").replace(/\.git$/, "");
			window.system?.openInBrowser?.(url);
		} catch (e) { window.toast?.(errText(e)); }
	}

	// ================= Project Manager =================
	async function pmSave() {
		const f = folders()[0];
		if (!f) return window.toast?.("Open a folder first");
		const name = await ask("Project name", f.title || "My project");
		if (!name) return;
		const list = store.get("projects", []).filter((p) => p.url !== f.url);
		list.unshift({ name, url: f.url });
		store.set("projects", list);
		window.toast?.("Project saved");
	}
	async function pmOpen() {
		const list = store.get("projects", []);
		if (!list.length) return window.toast?.("No saved projects. Open a folder and use Project Manager: Save project.");
		const i = await pick("Projects", list.map((p, i) => [String(i), `${p.name}`, "folder"]));
		if (i === undefined || i === null) return;
		const p = list[Number(i)];
		const open = folders();
		if (open.length && (await acode.require("confirm")("Switch project", "Close the folders open now?"))) {
			for (const f of [...open]) f.remove?.();
		}
		acode.require("openfolder")(p.url, { name: p.name });
	}
	async function pmRemove() {
		const list = store.get("projects", []);
		if (!list.length) return window.toast?.("No saved projects");
		const i = await pick("Remove project", list.map((p, i) => [String(i), p.name, "delete"]));
		if (i === undefined || i === null) return;
		list.splice(Number(i), 1);
		store.set("projects", list);
		window.toast?.("Removed");
	}

	// ================= SQL (SQLite / MySQL / PostgreSQL) =================
	function sqlCommand(conn, sql) {
		const q = shellQuote(sql);
		if (conn.type === "sqlite") return `command -v sqlite3 >/dev/null || apk add --no-cache sqlite >/dev/null; sqlite3 -csv -header ${shellQuote(conn.path)} ${q}`;
		if (conn.type === "mysql") return `command -v mariadb >/dev/null || apk add --no-cache mariadb-client >/dev/null; MYSQL_PWD=${shellQuote(conn.password || "")} mariadb --batch -h ${shellQuote(conn.host)} -P ${Number(conn.port) || 3306} -u ${shellQuote(conn.user)} ${conn.database ? shellQuote(conn.database) : ""} -e ${q}`;
		return `command -v psql >/dev/null || apk add --no-cache postgresql17-client >/dev/null || apk add --no-cache postgresql16-client >/dev/null; PGPASSWORD=${shellQuote(conn.password || "")} psql --csv -h ${shellQuote(conn.host)} -p ${Number(conn.port) || 5432} -U ${shellQuote(conn.user)} -d ${shellQuote(conn.database || "postgres")} -c ${q}`;
	}
	async function runSql(conn, sql) {
		const out = await sh(sqlCommand(conn, sql));
		return parseDelimited(out.replace(/\n$/, ""), conn.type === "mysql" ? "\t" : ",");
	}
	async function pickDbFile() {
		const p = activePath();
		if (p && /\.(db|sqlite3?|db3)$/i.test(p)) return p;
		const fb = acode.require("fileBrowser");
		const res = await fb("file", "Select SQLite database (.db / .sqlite)");
		const path = toTerm(res?.url);
		if (!path) window.toast?.("Pick a database from phone storage");
		return path;
	}
	function queryPage(title, conn, tables, initial) {
		const pg = showPage(title, `
<div class="cg-muted">${esc(conn.type === "sqlite" ? conn.path : `${conn.type}://${conn.user}@${conn.host}/${conn.database || ""}`)}</div>
${tables ? `<div class="cg-row">${tables.map((t) => `<button class="sec" data-t="${esc(t)}">${esc(t)}</button>`).join("") || '<span class="cg-muted">No tables</span>'}</div>` : ""}
<textarea id="sql">${esc(initial || "")}</textarea>
<div class="cg-row"><button id="run">Run</button><span id="st" class="cg-muted"></span></div>
<div id="res"></div>`, "sql");
		const run = async () => {
			const sql = pg.$("#sql").value.trim();
			if (!sql) return;
			pg.$("#st").textContent = "Running...";
			const t = Date.now();
			try {
				const rows = await runSql(conn, sql);
				pg.$("#res").innerHTML = tableHtml(rows);
				pg.$("#st").innerHTML = `<span class="cg-ok">Done in ${Date.now() - t} ms</span>`;
			} catch (e) {
				pg.$("#res").innerHTML = "";
				pg.$("#st").innerHTML = `<span class="cg-bad">${esc(errText(e))}</span>`;
			}
		};
		pg.$("#run").onclick = run;
		pg.wrap.querySelectorAll("[data-t]").forEach((b) => (b.onclick = () => {
			pg.$("#sql").value = `SELECT * FROM "${b.dataset.t}" LIMIT 200;`;
			run();
		}));
		if (initial) run();
		return pg;
	}
	async function sqliteOpen() {
		const path = await pickDbFile();
		if (!path || !(await hasAllFilesAccess(path))) return;
		const conn = { type: "sqlite", path };
		try {
			const rows = await runSql(conn, "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name;");
			queryPage(path.split("/").pop(), conn, rows.slice(1).map((r) => r[0]), rows.length > 1 ? `SELECT * FROM "${rows[1][0]}" LIMIT 200;` : "");
		} catch (e) { window.toast?.(errText(e)); }
	}
	async function sqliteNew() {
		const dir = projectDir() || "/sdcard";
		const name = await ask("New database file name", "data.db");
		if (!name) return;
		const path = `${dir}/${name}`;
		if (!(await hasAllFilesAccess(path))) return;
		try {
			await runSql({ type: "sqlite", path }, "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, text TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);");
			window.toast?.(`Created ${name} with a sample "notes" table`);
			queryPage(name, { type: "sqlite", path }, ["notes"], "SELECT * FROM notes;");
		} catch (e) { window.toast?.(errText(e)); }
	}
	async function connAdd() {
		const type = await pick("Database type", [["sqlite", "SQLite file", "storage"], ["mysql", "MySQL / MariaDB", "dns"], ["postgres", "PostgreSQL", "dns"]]);
		if (!type) return;
		let conn;
		if (type === "sqlite") {
			const path = await pickDbFile();
			if (!path) return;
			conn = { type, path, name: path.split("/").pop() };
		} else {
			const host = await ask("Host", "127.0.0.1");
			if (!host) return;
			const port = await ask("Port", type === "mysql" ? "3306" : "5432", "number");
			const user = await ask("User", type === "mysql" ? "root" : "postgres");
			const password = (await ask("Password", "", "password")) || "";
			const database = (await ask("Database (optional)", "")) || "";
			conn = { type, host, port, user, password, database, name: `${type} ${user}@${host}/${database}` };
		}
		const list = store.get("connections", []);
		list.push(conn);
		store.set("connections", list);
		try {
			await runSql(conn, "SELECT 1;");
			window.toast?.("Connected ✓ Saved");
		} catch (e) { window.toast?.(`Saved, but test failed: ${errText(e)}`); }
	}
	async function connPick() {
		const list = store.get("connections", []);
		if (!list.length) {
			window.toast?.("Add a connection first");
			await connAdd();
			return store.get("connections", [])[0] || null;
		}
		const i = list.length === 1 ? "0" : await pick("Connection", list.map((c, i) => [String(i), c.name, "storage"]));
		return i === undefined || i === null ? null : list[Number(i)];
	}
	async function sqlRunCurrent() {
		const v = view();
		if (!v) return;
		const sel = v.state.selection.main;
		let sql = v.state.sliceDoc(sel.from, sel.to);
		if (!sql.trim()) {
			const doc = v.state.doc.toString();
			const parts = doc.split(/;\s*(?:\n|$)/);
			let off = 0;
			for (const p of parts) {
				if (sel.head <= off + p.length + 1) { sql = p; break; }
				off += p.length + 1;
				while (/\s/.test(doc[off] || "")) off++;
			}
		}
		if (!sql.trim()) return window.toast?.("Put the cursor in a SQL statement");
		const conn = await connPick();
		if (!conn) return;
		if (conn.type === "sqlite" && !(await hasAllFilesAccess(conn.path))) return;
		queryPage("Query result", conn, null, sql.trim().replace(/;?$/, ";"));
	}
	async function connOpen() {
		const conn = await connPick();
		if (!conn) return;
		const listSql = conn.type === "sqlite" ? "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;" : conn.type === "mysql" ? "SHOW TABLES;" : "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY 1;";
		try {
			const rows = await runSql(conn, listSql);
			queryPage(conn.name, conn, rows.slice(1).map((r) => r[0]), "");
		} catch (e) { window.toast?.(errText(e)); }
	}
	async function connRemove() {
		const list = store.get("connections", []);
		if (!list.length) return window.toast?.("No connections");
		const i = await pick("Remove connection", list.map((c, i) => [String(i), c.name, "delete"]));
		if (i === undefined || i === null) return;
		list.splice(Number(i), 1);
		store.set("connections", list);
	}

	// ================= API Client (GUI) =================
	function apiClientPage(prefill) {
		const hist = store.get("history", []);
		const r = prefill || hist[0] || { method: "GET", url: "https://jsonplaceholder.typicode.com/todos/1", headers: "Accept: application/json", body: "" };
		const pg = showPage("API Client", `
<div class="cg-row"><select id="m">${["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"].map((m) => `<option ${m === r.method ? "selected" : ""}>${m}</option>`).join("")}</select><input id="u" style="flex:1;min-width:180px" value="${esc(r.url)}"><button id="send">Send</button></div>
<div class="cg-muted">Headers (one per line, Name: value)</div><textarea id="h" style="min-height:60px">${esc(r.headers)}</textarea>
<div class="cg-muted">Body</div><textarea id="b">${esc(r.body)}</textarea>
<div class="cg-row"><button class="sec" id="json">+ JSON header</button><button class="sec" id="bearer">+ Bearer token</button><button class="sec" id="hist">History (${hist.length})</button><button class="sec" id="save">Save as .http</button></div>
<div id="st" class="cg-muted"></div><div id="rh" class="cg-mono cg-muted" style="max-height:120px"></div><pre id="out" class="cg-mono" style="white-space:pre-wrap"></pre>`, "api");
		const read = () => ({ method: pg.$("#m").value, url: pg.$("#u").value.trim(), headers: pg.$("#h").value, body: pg.$("#b").value });
		pg.$("#json").onclick = () => { pg.$("#h").value = `${pg.$("#h").value.trim()}\nContent-Type: application/json`.trim(); };
		pg.$("#bearer").onclick = async () => { const t = await ask("Token", ""); if (t) pg.$("#h").value = `${pg.$("#h").value.trim()}\nAuthorization: Bearer ${t}`.trim(); };
		pg.$("#hist").onclick = async () => {
			const h = store.get("history", []);
			if (!h.length) return;
			const i = await pick("History", h.map((x, i) => [String(i), `${x.method} ${x.url}`, "history"]));
			if (i === undefined || i === null) return;
			pg.page.hide();
			apiClientPage(h[Number(i)]);
		};
		pg.$("#save").onclick = () => { const x = read(); openText("request.http", `### Request\n${x.method} ${x.url}\n${x.headers.trim()}\n\n${x.body}`); };
		pg.$("#send").onclick = async () => {
			const x = read();
			if (!/^https?:\/\//.test(x.url)) return window.toast?.("URL must start with http:// or https://");
			const headers = {};
			x.headers.split("\n").forEach((l) => { const m = /^\s*([\w-]+)\s*:\s*(.*)$/.exec(l); if (m) headers[m[1]] = m[2]; });
			pg.$("#st").textContent = "Sending...";
			pg.$("#out").textContent = "";
			pg.$("#rh").textContent = "";
			try {
				const res = await httpSend({ method: x.method, url: x.url, headers, body: x.body });
				let data = res.data;
				try { data = JSON.stringify(JSON.parse(data), null, 2); } catch (_) {}
				const okc = res.status < 400 ? "cg-ok" : "cg-bad";
				pg.$("#st").innerHTML = `<span class="${okc}"><b>${res.status}</b></span> • ${res.ms} ms • ${(String(res.data).length / 1024).toFixed(1)} KB`;
				pg.$("#rh").textContent = Object.entries(res.headers).map(([k, v]) => `${k}: ${v}`).join("\n");
				pg.$("#out").textContent = data;
			} catch (e) {
				pg.$("#st").innerHTML = `<span class="cg-bad">${esc(errText(e))}</span>`;
			}
			const h = store.get("history", []).filter((y) => !(y.method === x.method && y.url === x.url));
			h.unshift(x);
			store.set("history", h.slice(0, 30));
		};
	}

	// ================= Docker (remote over SSH) =================
	const DOCKER_SETUP = "command -v docker >/dev/null || apk add --no-cache docker-cli docker-cli-compose openssh-client >/dev/null";
	async function dockerHost(forceAsk) {
		let h = store.get("host", "");
		if (!h || forceAsk) {
			h = await ask("Docker server (SSH). Example: ssh://user@192.168.1.10", h || "ssh://");
			if (!h) return null;
			store.set("host", h);
		}
		return h;
	}
	async function dockerRun(title, cmd, useDir) {
		const host = await dockerHost(false);
		if (!host) return;
		await openTerminal("Docker", `${DOCKER_SETUP}; export DOCKER_HOST=${shellQuote(host)}; echo "Docker server: $DOCKER_HOST"; ${cmd}`, useDir ? projectDir() : "");
	}
	async function dockerPs() {
		const host = await dockerHost(false);
		if (!host) return;
		try {
			const out = await sh(`${DOCKER_SETUP}; DOCKER_HOST=${shellQuote(host)} docker ps -a --format '{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}'`);
			const rows = out.split("\n").filter(Boolean).map((l) => l.split("\t"));
			if (!rows.length) return window.toast?.("No containers");
			const id = await pick("Containers", rows.map((r) => [r[0], `${r[1]}  (${r[2]}) — ${r[3]}`, /^Up/.test(r[3]) ? "play_arrow" : "stop"]));
			if (!id) return;
			const act = await pick("Container", [["logs", "Logs (follow)", "notes"], ["sh", "Open shell", "terminal"], ["restart", "Restart", "refresh"], ["stop", "Stop", "stop"], ["start", "Start", "play_arrow"], ["rm", "Remove", "delete"]]);
			if (!act) return;
			if (act === "logs") dockerRun("Docker", `docker logs -f --tail 200 ${id}`);
			else if (act === "sh") dockerRun("Docker", `docker exec -it ${id} sh -c 'command -v bash >/dev/null && exec bash || exec sh'`);
			else { await sh(`${DOCKER_SETUP}; DOCKER_HOST=${shellQuote(host)} docker ${act === "rm" ? "rm -f" : act} ${id}`); window.toast?.(`${act} done`); }
		} catch (e) { window.toast?.(`Docker: ${errText(e)}. Check SSH key login to the server (SSH Remote: Create key).`); }
	}

	// ================= SSH Remote =================
	const SSH_SETUP = "command -v ssh >/dev/null || apk add --no-cache openssh-client >/dev/null";
	async function sshPickHost() {
		const hosts = store.get("hosts", []);
		const i = await pick("SSH hosts", [["__add", "+ Add host", "add"], ...hosts.map((h, i) => [String(i), `${h.user}@${h.host}:${h.port}`, "dns"])]);
		if (i === undefined || i === null) return null;
		if (i !== "__add") return hosts[Number(i)];
		const host = await ask("Host or IP", "");
		if (!host) return null;
		const user = await ask("User", "root");
		if (!user) return null;
		const port = (await ask("Port", "22", "number")) || "22";
		const h = { host, user, port };
		hosts.push(h);
		store.set("hosts", hosts);
		return h;
	}
	async function sshConnect() {
		const h = await sshPickHost();
		if (h) openTerminal(`SSH ${h.host}`, `${SSH_SETUP}; ssh -o StrictHostKeyChecking=accept-new -p ${Number(h.port) || 22} ${shellQuote(`${h.user}@${h.host}`)}`, "");
	}
	async function sshKey() {
		await openTerminal("SSH key", `${SSH_SETUP}; [ -f ~/.ssh/id_ed25519 ] || ssh-keygen -t ed25519 -N '' -f ~/.ssh/id_ed25519; echo; echo "Your public key (add it to the server's ~/.ssh/authorized_keys or GitHub):"; echo; cat ~/.ssh/id_ed25519.pub; echo; echo "Or run: ssh-copy-id -p PORT user@host"`, "");
	}
	async function sshUpload() {
		const p = needFile();
		if (!p) return;
		const h = await sshPickHost();
		if (!h) return;
		const dest = await ask("Remote folder", "~/");
		if (dest === null) return;
		openTerminal("SSH upload", `${SSH_SETUP}; scp -P ${Number(h.port) || 22} ${shellQuote(p)} ${shellQuote(`${h.user}@${h.host}:${dest}`)} && echo "Uploaded."`, dirOf(p));
	}
	async function sshSyncFolder() {
		const dir = projectDir();
		if (!dir) return window.toast?.("Open a folder first");
		const h = await sshPickHost();
		if (!h) return;
		const dest = await ask("Remote folder to sync into", `~/${dir.split("/").pop()}`);
		if (!dest) return;
		openTerminal("SSH sync", `${SSH_SETUP}; command -v rsync >/dev/null || apk add --no-cache rsync >/dev/null; rsync -avz --exclude node_modules --exclude .git -e ${shellQuote(`ssh -p ${Number(h.port) || 22}`)} ./ ${shellQuote(`${h.user}@${h.host}:${dest}/`)} && echo "Synced."`, dir);
	}
	async function sshMount() {
		const h = await sshPickHost();
		if (!h) return;
		window.toast?.("To edit remote files: Files sidebar > Add folder > FTP/SFTP, then enter this host.");
		try { acode.require("fileBrowser")("folder", "Add SFTP: tap + > SFTP"); } catch (_) {}
	}


	const FEATURE_COMMANDS = {
		liveServer: [["live-server-start", "Start (open in browser)", liveStart], ["live-server-stop", "Stop", liveStop]],
		jsDebug: [["js-debug-current", "Debug current file (Node inspector)", () => nodeRun(true)], ["js-run-current", "Run current file (Node)", () => nodeRun(false)]],
		cssPeek: [["css-peek", "Peek CSS definition", cssPeek]],
		prettier: [["prettier-format", "Format document", prettierFormat], ["prettier-toggle-save", "Toggle format on save", prettierToggle]],
		gitHistory: [["git-scm", "Source Control (status, commit, push, pull)", gitStatusPage], ["git-blame-line", "Blame current line (show commit)", blameLine], ["git-file-history", "File history", fileHistory], ["git-toggle-blame", "Toggle inline blame", toggleInlineBlame], ["git-init", "Init repository", gitInit]],
		gitGraph: [["git-graph", "Show graph", gitGraphPage], ["git-branches", "Branches / checkout", () => gitBranches()]],
		githubPR: [["gh-pr-list", "Pull requests", prList], ["gh-pr-create", "Create pull request", prCreate], ["gh-login", "Login to GitHub", ghLogin]],
		githubRepos: [["gh-repo-clone", "Clone repository", repoClone], ["gh-repo-web", "Open repository on GitHub", repoWeb], ["gh-login-repos", "Login to GitHub", ghLogin]],
		projectManager: [["pm-open", "Open project", pmOpen], ["pm-save", "Save current folder as project", pmSave], ["pm-remove", "Remove project", pmRemove]],
		sqlite: [["sqlite-open", "Open database", sqliteOpen], ["sqlite-new", "New database", sqliteNew]],
		sqlTools: [["sql-run", "Run query (selection or statement)", sqlRunCurrent], ["sql-browse", "Browse connection", connOpen], ["sql-add", "Add connection", connAdd], ["sql-remove", "Remove connection", connRemove]],
		apiClient: [["api-client", "New request", () => apiClientPage()]],
		docker: [["docker-ps", "Containers", dockerPs], ["docker-images", "Images", () => dockerRun("Docker", "docker images")], ["docker-compose-up", "Compose up (current folder)", () => dockerRun("Docker", "docker compose up -d --build && docker compose ps", true)], ["docker-compose-down", "Compose down", () => dockerRun("Docker", "docker compose down", true)], ["docker-build", "Build image (current folder)", async () => { const t = await ask("Image name:tag", "myapp:latest"); if (t) dockerRun("Docker", `docker build -t ${shellQuote(t)} .`, true); }], ["docker-host", "Set Docker server (SSH)", () => dockerHost(true)]],
		ssh: [["ssh-connect", "Connect (terminal)", sshConnect], ["ssh-key", "Create / show SSH key", sshKey], ["ssh-upload", "Upload current file (scp)", sshUpload], ["ssh-sync", "Sync folder to server (rsync)", sshSyncFolder], ["ssh-sftp", "Edit remote files (SFTP)", sshMount]],
	};
	const FEATURE_EXTENSIONS = { autoRenameTag: renameTagExtension, htmlCss: classCompletionExtension, gitHistory: inlineBlameExtension };

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		for (const server of CFG.servers || []) {
			if (!lsp) break;
			const [kind, options] = server.installer;
			lsp.upsert(lsp.defineServer({ ...server, installer: lsp.installers[kind](options), enabled: true }));
		}
		if (CFG.snippets?.length) addCommand(`${CFG.key}-snippets`, `${TITLE}: Insert snippet`, pickSnippet);
		for (const t of CFG.terminal || []) addCommand(`${CFG.key}-${t.id}`, `${TITLE}: ${t.title}`, () => runInTerminal(t));
		if (CFG.rest) addCommand("rest-send-request", `${TITLE}: Send request`, sendRequest);
		if (CFG.openapi) addCommand("openapi-preview", `${TITLE}: Preview API docs`, previewOpenApi);
		for (const f of CFG.features || []) {
			for (const [name, label, fn] of FEATURE_COMMANDS[f] || []) addCommand(name, `${TITLE}: ${label}`, fn);
			if (FEATURE_EXTENSIONS[f]) {
				try {
					acode.require("editorExtensions")?.add(`${PLUGIN_ID}.${f}`, FEATURE_EXTENSIONS[f]());
				} catch (e) {
					console.warn(e);
				}
			}
		}
		for (const id of CFG.builtins || []) lsp?.servers.update(id, () => ({ enabled: true }));
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE} added. Open Command Palette and search "${TITLE}".`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		for (const name of added.splice(0)) acode.removeCommand(name);
		const lsp = acode.require("lsp");
		for (const server of CFG.servers || []) lsp?.servers.unregister(server.id);
		for (const id of CFG.builtins || []) lsp?.servers.update(id, () => ({ enabled: false }));
		for (const f of CFG.features || []) {
			if (FEATURE_EXTENSIONS[f]) acode.require("editorExtensions")?.remove(`${PLUGIN_ID}.${f}`);
		}
	});
})();
