(() => {
	const PLUGIN_ID = "codegallery.python-snippets";
	const TITLE = "Python Snippets";
	const COMMAND = "python-snippets";
	const SNIPPETS = [
 [
  "if __name__ == '__main__'",
  "def main():\n    $0\n\n\nif __name__ == \"__main__\":\n    main()\n"
 ],
 [
  "Function",
  "def function_name(arg):\n    \"\"\"Describe what it does.\"\"\"\n    $0\n    return None\n"
 ],
 [
  "Class",
  "class ClassName:\n    def __init__(self, value):\n        self.value = value\n\n    def __repr__(self):\n        return f\"ClassName({self.value!r})\"\n$0"
 ],
 [
  "Dataclass",
  "from dataclasses import dataclass\n\n\n@dataclass\nclass Item:\n    name: str\n    price: float = 0.0\n$0"
 ],
 [
  "For loop with index",
  "for i, item in enumerate(items):\n    $0\n"
 ],
 [
  "Try / except",
  "try:\n    $0\nexcept Exception as error:\n    print(f\"Error: {error}\")\n"
 ],
 [
  "Read file",
  "with open(\"file.txt\", encoding=\"utf-8\") as f:\n    text = f.read()\n$0"
 ],
 [
  "Write file",
  "with open(\"file.txt\", \"w\", encoding=\"utf-8\") as f:\n    f.write($0)\n"
 ],
 [
  "List comprehension",
  "result = [x for x in items if $0]\n"
 ],
 [
  "Argparse CLI",
  "import argparse\n\nparser = argparse.ArgumentParser(description=\"$0\")\nparser.add_argument(\"name\")\nargs = parser.parse_args()\nprint(args.name)\n"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
