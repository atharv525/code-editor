(() => {
	const PLUGIN_ID = "codegallery.java";
	const TITLE = "Java";
	const EXT = ".java";
	const BUILTIN = [];
	const SERVER = {
 "id": "jdtls",
 "label": "Java (Eclipse JDT LS)",
 "languages": [
  "java"
 ],
 "command": "jdtls",
 "args": [
  "-data",
  "/tmp/jdtls-workspace"
 ],
 "checkCommand": "which jdtls",
 "startupTimeout": 120000,
 "installer": [
  "apk",
  {
   "executable": "jdtls",
   "packages": [
    "jdtls",
    "openjdk17-jdk"
   ]
  }
 ]
};

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: true }));
			}
		} else if (SERVER) {
			const [kind, options] = SERVER.installer;
			const manifest = lsp.defineServer({
				...SERVER,
				installer: lsp.installers[kind](options),
				enabled: true,
			});
			lsp.upsert(manifest);
		}
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(
				`${TITLE} added. Open a ${EXT} file; the language server installs once (needs internet).`,
			);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: false }));
			}
		} else if (SERVER) {
			lsp.servers.unregister(SERVER.id);
		}
	});
})();
