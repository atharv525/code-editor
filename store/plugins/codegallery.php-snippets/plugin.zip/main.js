(() => {
	const PLUGIN_ID = "codegallery.php-snippets";
	const TITLE = "PHP Snippets";
	const COMMAND = "php-snippets";
	const SNIPPETS = [
 [
  "PHP page",
  "<?php\n$title = \"My page\";\n?>\n<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <title><?= htmlspecialchars($title) ?></title>\n</head>\n<body>\n  $0\n</body>\n</html>\n"
 ],
 [
  "Function",
  "function functionName($arg)\n{\n    $0\n    return $arg;\n}\n"
 ],
 [
  "Class",
  "class ClassName\n{\n    public function __construct(private string $name)\n    {\n    }\n\n    public function getName(): string\n    {\n        return $this->name;\n    }\n}\n$0"
 ],
 [
  "foreach",
  "foreach ($items as $key => $value) {\n    $0\n}\n"
 ],
 [
  "Form POST handler",
  "if ($_SERVER[\"REQUEST_METHOD\"] === \"POST\") {\n    $name = trim($_POST[\"name\"] ?? \"\");\n    $0\n}\n"
 ],
 [
  "PDO SQLite connect",
  "$pdo = new PDO(\"sqlite:\" . __DIR__ . \"/data.db\");\n$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);\n$stmt = $pdo->prepare(\"SELECT * FROM users WHERE id = ?\");\n$stmt->execute([$0]);\n$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);\n"
 ],
 [
  "JSON API response",
  "header(\"Content-Type: application/json\");\necho json_encode([\n    \"ok\" => true,\n    \"data\" => $0,\n]);\nexit;\n"
 ],
 [
  "Session start",
  "session_start();\n$_SESSION[\"user\"] = $0;\n"
 ],
 [
  "try / catch",
  "try {\n    $0\n} catch (Throwable $e) {\n    echo \"Error: \" . $e->getMessage();\n}\n"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
