(() => {
	const PLUGIN_ID = "codegallery.javascript-snippets";
	const TITLE = "JavaScript Snippets";
	const COMMAND = "javascript-snippets";
	const SNIPPETS = [
 [
  "Arrow function",
  "const functionName = (arg) => {\n  $0\n};\n"
 ],
 [
  "Async fetch JSON",
  "async function getData() {\n  try {\n    const res = await fetch(\"$0\");\n    if (!res.ok) throw new Error(res.status);\n    return await res.json();\n  } catch (error) {\n    console.error(error);\n  }\n}\n"
 ],
 [
  "DOM click event",
  "document.querySelector(\"#button\").addEventListener(\"click\", (event) => {\n  $0\n});\n"
 ],
 [
  "Class",
  "class ClassName {\n  constructor(value) {\n    this.value = value;\n  }\n\n  method() {\n    $0\n  }\n}\n"
 ],
 [
  "Array map / filter",
  "const result = items\n  .filter((item) => $0)\n  .map((item) => item);\n"
 ],
 [
  "Debounce",
  "function debounce(fn, delay = 300) {\n  let timer;\n  return (...args) => {\n    clearTimeout(timer);\n    timer = setTimeout(() => fn(...args), delay);\n  };\n}\n$0"
 ],
 [
  "localStorage JSON",
  "const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));\nconst load = (key, fallback = null) => JSON.parse(localStorage.getItem(key)) ?? fallback;\n$0"
 ],
 [
  "Node HTTP server",
  "const http = require(\"http\");\n\nhttp\n  .createServer((req, res) => {\n    res.writeHead(200, { \"Content-Type\": \"text/plain\" });\n    res.end(\"Hello$0\");\n  })\n  .listen(3000, () => console.log(\"http://localhost:3000\"));\n"
 ],
 [
  "Promise timeout",
  "const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));\nawait sleep($0);\n"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
