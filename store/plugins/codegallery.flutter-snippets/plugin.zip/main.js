(() => {
	const PLUGIN_ID = "codegallery.flutter-snippets";
	const TITLE = "Flutter Snippets";
	const COMMAND = "flutter-snippets";
	const SNIPPETS = [
 [
  "Flutter app (main.dart)",
  "import 'package:flutter/material.dart';\n\nvoid main() => runApp(const MyApp());\n\nclass MyApp extends StatelessWidget {\n  const MyApp({super.key});\n\n  @override\n  Widget build(BuildContext context) {\n    return MaterialApp(\n      title: 'My App',\n      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),\n      home: const HomePage(),\n    );\n  }\n}\n$0"
 ],
 [
  "StatelessWidget",
  "class MyWidget extends StatelessWidget {\n  const MyWidget({super.key});\n\n  @override\n  Widget build(BuildContext context) {\n    return $0Container();\n  }\n}\n"
 ],
 [
  "StatefulWidget",
  "class MyWidget extends StatefulWidget {\n  const MyWidget({super.key});\n\n  @override\n  State<MyWidget> createState() => _MyWidgetState();\n}\n\nclass _MyWidgetState extends State<MyWidget> {\n  @override\n  Widget build(BuildContext context) {\n    return $0Container();\n  }\n}\n"
 ],
 [
  "Scaffold page",
  "Scaffold(\n  appBar: AppBar(title: const Text('Title')),\n  body: Center(child: $0),\n  floatingActionButton: FloatingActionButton(\n    onPressed: () {},\n    child: const Icon(Icons.add),\n  ),\n)"
 ],
 [
  "ListView.builder",
  "ListView.builder(\n  itemCount: items.length,\n  itemBuilder: (context, index) {\n    final item = items[index];\n    return ListTile(title: Text(item$0));\n  },\n)"
 ],
 [
  "Column",
  "Column(\n  crossAxisAlignment: CrossAxisAlignment.start,\n  children: [\n    $0\n  ],\n)"
 ],
 [
  "Row",
  "Row(\n  mainAxisAlignment: MainAxisAlignment.spaceBetween,\n  children: [\n    $0\n  ],\n)"
 ],
 [
  "FutureBuilder",
  "FutureBuilder(\n  future: $0,\n  builder: (context, snapshot) {\n    if (snapshot.connectionState != ConnectionState.done) {\n      return const CircularProgressIndicator();\n    }\n    if (snapshot.hasError) return Text('Error: ${snapshot.error}');\n    return Text('${snapshot.data}');\n  },\n)"
 ],
 [
  "Navigate to page",
  "Navigator.push(\n  context,\n  MaterialPageRoute(builder: (_) => const $0()),\n);"
 ],
 [
  "setState",
  "setState(() {\n  $0\n});"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
