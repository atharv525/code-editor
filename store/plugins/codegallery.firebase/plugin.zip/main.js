(() => {
	const PLUGIN_ID = "codegallery.firebase";
	const TITLE = "Firebase";
	const CFG = {
 "key": "firebase",
 "snippets": [
  [
   "initialize app (web)",
   "import { initializeApp } from 'firebase/app';\nimport { getAuth } from 'firebase/auth';\nimport { getFirestore } from 'firebase/firestore';\n\nconst firebaseConfig = {\n  apiKey: '$0',\n  authDomain: '',\n  projectId: '',\n  storageBucket: '',\n  messagingSenderId: '',\n  appId: '',\n};\n\nexport const app = initializeApp(firebaseConfig);\nexport const auth = getAuth(app);\nexport const db = getFirestore(app);\n"
  ],
  [
   "Auth: email sign in",
   "import { signInWithEmailAndPassword } from 'firebase/auth';\n\nconst { user } = await signInWithEmailAndPassword(auth, email, password);$0"
  ],
  [
   "Auth: Google sign in",
   "import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';\n\nconst { user } = await signInWithPopup(auth, new GoogleAuthProvider());$0"
  ],
  [
   "Firestore: add doc",
   "import { collection, addDoc, serverTimestamp } from 'firebase/firestore';\n\nawait addDoc(collection(db, '$0items'), { name, createdAt: serverTimestamp() });"
  ],
  [
   "Firestore: get docs",
   "import { collection, getDocs, query, where } from 'firebase/firestore';\n\nconst snap = await getDocs(query(collection(db, '$0items'), where('done', '==', false)));\nconst items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));"
  ],
  [
   "Firestore: realtime listener",
   "import { doc, onSnapshot } from 'firebase/firestore';\n\nconst unsub = onSnapshot(doc(db, '$0items', id), (d) => {\n  console.log(d.data());\n});"
  ],
  [
   "Firestore: update / delete",
   "import { doc, updateDoc, deleteDoc } from 'firebase/firestore';\n\nawait updateDoc(doc(db, 'items', id), { $0 });\nawait deleteDoc(doc(db, 'items', id));"
  ],
  [
   "Storage: upload file",
   "import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';\n\nconst r = ref(getStorage(app), `uploads/${file.name}`);\nawait uploadBytes(r, file);\nconst url = await getDownloadURL(r);$0"
  ],
  [
   "firestore.rules",
   "rules_version = '2';\nservice cloud.firestore {\n  match /databases/{database}/documents {\n    match /users/{userId} {\n      allow read, write: if request.auth != null && request.auth.uid == userId;\n    }\n  }\n}\n$0"
  ]
 ],
 "servers": [],
 "terminal": [
  {
   "id": "login",
   "title": "CLI login",
   "cmd": "apk add --no-cache nodejs npm >/dev/null && (which firebase >/dev/null || npm install -g firebase-tools) && firebase login --no-localhost"
  },
  {
   "id": "init",
   "title": "firebase init",
   "cmd": "apk add --no-cache nodejs npm >/dev/null && (which firebase >/dev/null || npm install -g firebase-tools) && firebase init"
  },
  {
   "id": "deploy",
   "title": "firebase deploy",
   "cmd": "apk add --no-cache nodejs npm >/dev/null && (which firebase >/dev/null || npm install -g firebase-tools) && firebase deploy"
  }
 ],
 "rest": false,
 "openapi": false
};
	const added = [];

	function view() {
		const v = window.editorManager?.editor;
		if (!v) window.toast?.("Open a file first");
		return v;
	}

	function insert(v, body) {
		const sel = v.state.selection.main;
		const line = v.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		v.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		v.focus();
	}

	async function pickSnippet() {
		const v = view();
		if (!v) return;
		const select = acode.require("select");
		const value = await select(
			`${TITLE} snippets`,
			CFG.snippets.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const s = CFG.snippets[Number(value)];
		if (s) insert(v, s[1]);
	}

	function shellQuote(s) {
		return `'${String(s).replace(/'/g, "'\\''")}'`;
	}

	function terminalDir() {
		const file = window.editorManager?.activeFile;
		const uri = file?.uri || window.addedFolder?.[0]?.url || "";
		const m = /\/storage\/emulated\/0(\/.*)?$/.exec(
			decodeURIComponent(uri).replace(/^.*?::/, "").replace(/^file:\/\//, ""),
		);
		if (!m) return "";
		let path = `/sdcard${m[1] || ""}`;
		if (file?.uri && !window.addedFolder?.length) {
			path = path.slice(0, path.lastIndexOf("/")) || "/sdcard";
		}
		return path;
	}

	async function runInTerminal(t) {
		let cmd = t.cmd;
		if (t.ask) {
			const prompt = acode.require("prompt");
			const value = await prompt(t.ask, t.askDefault || "", "text");
			if (value === null || value === undefined) return;
			cmd = cmd.replace("{input}", shellQuote(value));
		}
		const term = await acode.require("terminal").create({ name: t.title });
		if (!term?.component) return;
		const start = Date.now();
		while (!term.component.isConnected && Date.now() - start < 15000) {
			await new Promise((r) => setTimeout(r, 300));
		}
		await new Promise((r) => setTimeout(r, 800));
		const dir = terminalDir();
		const cd = dir ? `cd ${shellQuote(dir)} 2>/dev/null; ` : "";
		term.component.write(`clear; ${cd}${cmd}\n`);
	}

	// ---------- REST client (.http / .rest files) ----------
	function currentRequest(v) {
		const doc = v.state.doc.toString();
		const pos = v.state.selection.main.head;
		const vars = {};
		for (const m of doc.matchAll(/^@([\w-]+)\s*=\s*(.*)$/gm)) vars[m[1]] = m[2].trim();
		const blocks = doc.split(/^###.*$/m);
		let offset = 0;
		let block = blocks[0];
		for (const b of blocks) {
			const end = offset + b.length;
			block = b;
			if (pos <= end) break;
			offset = end + (doc.slice(end).match(/^###.*/)?.[0].length || 0);
		}
		const fill = (s) => s.replace(/\{\{\s*([\w-]+)\s*\}\}/g, (_, k) => vars[k] ?? "");
		const lines = block.split("\n").map((l) => l.replace(/\r$/, ""));
		let i = 0;
		while (i < lines.length && (/^\s*$/.test(lines[i]) || /^\s*(#|\/\/)/.test(lines[i]) || /^@[\w-]+\s*=/.test(lines[i]))) i++;
		if (i >= lines.length) return null;
		const first = fill(lines[i]).trim().split(/\s+/);
		let method = "GET";
		let url = first[0];
		if (/^[A-Z]+$/.test(first[0])) {
			method = first[0];
			url = first[1];
		}
		const headers = {};
		i++;
		for (; i < lines.length && lines[i].trim() !== ""; i++) {
			const m = /^([\w-]+)\s*:\s*(.*)$/.exec(fill(lines[i]));
			if (m) headers[m[1]] = m[2];
		}
		const body = fill(lines.slice(i + 1).join("\n")).trim();
		return { method, url, headers, body };
	}

	function httpSend(req) {
		return new Promise((resolve, reject) => {
			const http = window.cordova?.plugin?.http;
			const started = Date.now();
			if (!http) {
				fetch(req.url, {
					method: req.method,
					headers: req.headers,
					body: ["GET", "HEAD"].includes(req.method) ? undefined : req.body || undefined,
				})
					.then(async (res) => {
						const headers = {};
						res.headers.forEach((v, k) => (headers[k] = v));
						resolve({ status: res.status, headers, data: await res.text(), ms: Date.now() - started });
					})
					.catch(reject);
				return;
			}
			const options = {
				method: req.method.toLowerCase(),
				headers: req.headers,
				serializer: "utf8",
				responseType: "text",
				timeout: 60,
			};
			if (!["GET", "HEAD"].includes(req.method)) options.data = req.body || "";
			const done = (res) =>
				resolve({
					status: res.status,
					headers: res.headers || {},
					data: res.data ?? res.error ?? "",
					ms: Date.now() - started,
				});
			http.sendRequest(req.url, options, done, (err) =>
				err && err.status > 0 ? done(err) : reject(new Error(err?.error || "Request failed")),
			);
		});
	}

	async function sendRequest() {
		const v = view();
		if (!v) return;
		const req = currentRequest(v);
		if (!req || !/^https?:\/\//.test(req.url || "")) {
			window.toast?.("Put the cursor on a request like: GET https://example.com");
			return;
		}
		const loader = acode.require("loader");
		loader.showTitleLoader?.();
		try {
			const res = await httpSend(req);
			let data = res.data;
			try {
				data = JSON.stringify(JSON.parse(data), null, 2);
			} catch (_) {}
			const head = Object.entries(res.headers)
				.map(([k, val]) => `${k}: ${val}`)
				.join("\n");
			const text = `HTTP ${res.status}  (${res.ms} ms)\n${req.method} ${req.url}\n\n${head}\n\n${data}`;
			const EditorFile = acode.require("EditorFile");
			new EditorFile(`Response ${res.status}.http`, { text, isUnsaved: false });
		} catch (e) {
			window.toast?.(`Request failed: ${e.message || e}`);
		} finally {
			loader.removeTitleLoader?.();
		}
	}

	// ---------- OpenAPI preview ----------
	function previewOpenApi() {
		const v = view();
		if (!v) return;
		const spec = v.state.doc.toString();
		if (!/openapi|swagger/i.test(spec)) {
			window.toast?.("This file does not look like an OpenAPI / Swagger spec");
			return;
		}
		const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"><style>body{margin:0;background:#fff}</style></head><body><div id="ui">Loading preview (needs internet)...</div>
<script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script><script src="https://unpkg.com/js-yaml@4/dist/js-yaml.min.js"></script>
<script>try{const t=${JSON.stringify(spec).replace(/</g, "\\u003c")};let s;try{s=JSON.parse(t)}catch(_){s=jsyaml.load(t)}SwaggerUIBundle({spec:s,dom_id:"#ui"})}catch(e){document.body.textContent="Spec error: "+e.message}</script></body></html>`;
		const Page = acode.require("page");
		const page = Page("API Preview");
		const frame = document.createElement("iframe");
		frame.style.cssText = "width:100%;height:100%;border:0;background:#fff";
		frame.srcdoc = html;
		page.body = frame;
		window.app.append(page);
		const stack = acode.require("actionStack");
		stack?.push({ id: "openapi-preview", action: page.hide });
		page.onhide = () => stack?.remove("openapi-preview");
	}

	function addCommand(name, description, exec) {
		acode.addCommand({ name, description, requiresView: false, exec() { exec(); return true; } });
		added.push(name);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		for (const server of CFG.servers || []) {
			if (!lsp) break;
			const [kind, options] = server.installer;
			lsp.upsert(lsp.defineServer({ ...server, installer: lsp.installers[kind](options), enabled: true }));
		}
		if (CFG.snippets?.length) addCommand(`${CFG.key}-snippets`, `${TITLE}: Insert snippet`, pickSnippet);
		for (const t of CFG.terminal || []) addCommand(`${CFG.key}-${t.id}`, `${TITLE}: ${t.title}`, () => runInTerminal(t));
		if (CFG.rest) addCommand("rest-send-request", `${TITLE}: Send request`, sendRequest);
		if (CFG.openapi) addCommand("openapi-preview", `${TITLE}: Preview API docs`, previewOpenApi);
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE} added. Open Command Palette and search "${TITLE}".`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		for (const name of added.splice(0)) acode.removeCommand(name);
		const lsp = acode.require("lsp");
		for (const server of CFG.servers || []) lsp?.servers.unregister(server.id);
	});
})();
