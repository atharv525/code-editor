(() => {
	const PLUGIN_ID = "codegallery.intelephense";
	const TITLE = "PHP Intelephense";
	const EXT = ".php";
	const BUILTIN = [];
	const SERVER = {
 "id": "intelephense",
 "label": "PHP (Intelephense)",
 "languages": [
  "php"
 ],
 "command": "intelephense",
 "args": [
  "--stdio"
 ],
 "checkCommand": "which intelephense",
 "installer": [
  "npm",
  {
   "executable": "intelephense",
   "packages": [
    "intelephense"
   ]
  }
 ]
};

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: true }));
			}
		} else if (SERVER) {
			const [kind, options] = SERVER.installer;
			const manifest = lsp.defineServer({
				...SERVER,
				installer: lsp.installers[kind](options),
				enabled: true,
			});
			lsp.upsert(manifest);
		}
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(
				`${TITLE} added. Open a ${EXT} file; the language server installs once (needs internet).`,
			);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: false }));
			}
		} else if (SERVER) {
			lsp.servers.unregister(SERVER.id);
		}
	});
})();
