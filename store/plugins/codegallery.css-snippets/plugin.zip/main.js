(() => {
	const PLUGIN_ID = "codegallery.css-snippets";
	const TITLE = "CSS Snippets";
	const COMMAND = "css-snippets";
	const SNIPPETS = [
 [
  "Modern reset",
  "*, *::before, *::after {\n  box-sizing: border-box;\n  margin: 0;\n}\nbody {\n  line-height: 1.5;\n  font-family: system-ui, sans-serif;\n}\nimg {\n  max-width: 100%;\n  display: block;\n}\n$0"
 ],
 [
  "Flex center",
  "display: flex;\njustify-content: center;\nalign-items: center;\n$0"
 ],
 [
  "Responsive grid",
  ".grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));\n  gap: 16px;\n}\n$0"
 ],
 [
  "Media query (mobile)",
  "@media (max-width: 600px) {\n  $0\n}\n"
 ],
 [
  "CSS variables",
  ":root {\n  --primary: #6366f1;\n  --bg: #0f172a;\n  --text: #e2e8f0;\n}\n$0"
 ],
 [
  "Keyframe animation",
  "@keyframes fadeIn {\n  from { opacity: 0; transform: translateY(10px); }\n  to { opacity: 1; transform: none; }\n}\n.fade-in {\n  animation: fadeIn 0.4s ease-out both;\n}\n$0"
 ],
 [
  "Card",
  ".card {\n  background: #1e293b;\n  border-radius: 12px;\n  padding: 20px;\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);\n}\n$0"
 ],
 [
  "Button",
  ".btn {\n  padding: 10px 18px;\n  border: 0;\n  border-radius: 8px;\n  background: #6366f1;\n  color: #fff;\n  cursor: pointer;\n  transition: transform 0.15s, opacity 0.15s;\n}\n.btn:active {\n  transform: scale(0.97);\n}\n$0"
 ],
 [
  "Dark mode",
  "@media (prefers-color-scheme: dark) {\n  body {\n    background: #0f172a;\n    color: #e2e8f0;\n  }\n}\n$0"
 ]
];

	function insert(view, body) {
		const sel = view.state.selection.main;
		const line = view.state.doc.lineAt(sel.from);
		const indent = (line.text.match(/^\s*/) || [""])[0];
		const marker = body.indexOf("$0");
		const clean = body.replace("$0", "");
		const withIndent = (s) => s.split("\n").join(`\n${indent}`);
		const text = withIndent(clean);
		const cursor =
			marker < 0 ? text.length : withIndent(clean.slice(0, marker)).length;
		view.dispatch({
			changes: { from: sel.from, to: sel.to, insert: text },
			selection: { anchor: sel.from + cursor },
			scrollIntoView: true,
		});
		view.focus();
	}

	async function pick() {
		const view = window.editorManager?.editor;
		if (!view) {
			window.toast?.("Open a file first");
			return;
		}
		const select = acode.require("select");
		const value = await select(
			TITLE,
			SNIPPETS.map((s, i) => [String(i), s[0], "code"]),
		);
		if (value === undefined || value === null) return;
		const snippet = SNIPPETS[Number(value)];
		if (snippet) insert(view, snippet[1]);
	}

	acode.setPluginInit(PLUGIN_ID, () => {
		acode.addCommand({
			name: COMMAND,
			description: TITLE,
			requiresView: false,
			exec() {
				pick();
				return true;
			},
		});
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(`${TITLE}: open Command Palette and search "${TITLE}"`);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		acode.removeCommand(COMMAND);
	});
})();
