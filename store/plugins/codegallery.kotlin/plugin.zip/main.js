(() => {
	const PLUGIN_ID = "codegallery.kotlin";
	const TITLE = "Kotlin";
	const EXT = ".kt";
	const BUILTIN = [];
	const SERVER = {
 "id": "kotlin-language-server",
 "label": "Kotlin (kotlin-language-server)",
 "languages": [
  "kotlin"
 ],
 "command": "/opt/kotlin-language-server/server/bin/kotlin-language-server",
 "checkCommand": "test -x /opt/kotlin-language-server/server/bin/kotlin-language-server",
 "startupTimeout": 180000,
 "installer": [
  "shell",
  {
   "executable": "/opt/kotlin-language-server/server/bin/kotlin-language-server",
   "command": "apk add --no-cache openjdk17-jre curl unzip && TMP_DIR=\"$(mktemp -d)\" && curl -fL -o \"$TMP_DIR/server.zip\" https://github.com/fwcd/kotlin-language-server/releases/download/1.3.13/server.zip && rm -rf /opt/kotlin-language-server && mkdir -p /opt/kotlin-language-server && unzip -oq \"$TMP_DIR/server.zip\" -d /opt/kotlin-language-server && chmod +x /opt/kotlin-language-server/server/bin/kotlin-language-server && rm -rf \"$TMP_DIR\"",
   "uninstallCommand": "rm -rf /opt/kotlin-language-server"
  }
 ]
};

	acode.setPluginInit(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: true }));
			}
		} else if (SERVER) {
			const [kind, options] = SERVER.installer;
			const manifest = lsp.defineServer({
				...SERVER,
				installer: lsp.installers[kind](options),
				enabled: true,
			});
			lsp.upsert(manifest);
		}
		const key = `${PLUGIN_ID}.welcome`;
		if (!localStorage.getItem(key)) {
			localStorage.setItem(key, "1");
			window.toast?.(
				`${TITLE} added. Open a ${EXT} file; the language server installs once (needs internet).`,
			);
		}
	});

	acode.setPluginUnmount(PLUGIN_ID, () => {
		const lsp = acode.require("lsp");
		if (!lsp) return;
		if (BUILTIN.length) {
			for (const id of BUILTIN) {
				lsp.servers.update(id, () => ({ enabled: false }));
			}
		} else if (SERVER) {
			lsp.servers.unregister(SERVER.id);
		}
	});
})();
